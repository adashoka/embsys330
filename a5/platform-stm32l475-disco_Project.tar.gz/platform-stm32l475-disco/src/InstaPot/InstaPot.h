#ifndef INSTAPOT_H
#define INSTAPOT_H

#include "qpcpp.h"
#include "fw_active.h"
#include "fw_timer.h"
#include "fw_evt.h"
#include "app_hsmn.h"

using namespace QP;
using namespace FW;

namespace APP {
class InstaPot : public Active {
public:
	InstaPot();
protected:
	static QState InitialPseudoState(InstaPot * const me, QEvt const * const e);
	    static QState Root(InstaPot * const me, QEvt const * const e);
	        static QState Stopped(InstaPot * const me, QEvt const * const e);
	        static QState Started(InstaPot * const me, QEvt const * const e);

	Timer m_instaTimer;

#define INSTA_POT_TIMER_EVT \
    ADD_EVT(INSTA_TIMEOUT)

#define INSTA_POT_INTERNAL_EVT \
    ADD_EVT(DONE) \
    ADD_EVT(FAILED)

#undef ADD_EVT
#define ADD_EVT(e_) e_,

    enum {
        INSTA_POT_TIMER_EVT_START = TIMER_EVT_START(INSTA_POT),
        INSTA_POT_TIMER_EVT
    };

    enum {
    	INSTA_POT_INTERNAL_EVT_START = INTERNAL_EVT_START(INSTA_POT),
		INSTA_POT_INTERNAL_EVT
    };
};

}//namespace APP

#endif
