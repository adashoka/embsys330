#include "app_hsmn.h"
#include "fw_log.h"
#include "fw_assert.h"
#include "InstaPotInterface.h"
#include "InstaPot.h"

FW_DEFINE_THIS_FILE("InstaPot.cpp")

namespace APP {

#undef ADD_EVT
#define ADD_EVT(e_) #e_,

static char const * const timerEvtName[] = {
   "INSTA_POT_TIMER_EVT_START",
   INSTA_POT_TIMER_EVT
};

static char const * const internalEvtName[] = {
   "INSTA_POT_INTERNAL_EVT_START",
   INSTA_POT_INTERNAL_EVT
};

static char const * const interfaceEvtName[] = {
   "INSTA_POT_INTERFACE_EVT_START",
   INSTA_POT_INTERFACE_EVT
};


InstaPot::InstaPot() :
    Active((QStateHandler)&InstaPot::InitialPseudoState, INSTA_POT, "INSTA_POT"),
	m_instaTimer(GetHsm().GetHsmn(), INSTA_TIMEOUT) {
    SET_EVT_NAME(INSTA_POT);
}

QState InstaPot::InitialPseudoState(InstaPot * const me, QEvt const * const e) {
    (void)e;
    return Q_TRAN(&InstaPot::Root);
}

QState InstaPot::Root(InstaPot * const me, QEvt const * const e) {
    switch (e->sig) {
    	  case Q_ENTRY_SIG: {
              EVENT(e);
              return Q_HANDLED();
          }
          case Q_EXIT_SIG: {
              EVENT(e);
              return Q_HANDLED();
          }
          case Q_INIT_SIG: {
              return Q_TRAN(&InstaPot::Stopped);
          }
          case INSTA_SIM_START_REQ: {
              EVENT(e);
              Evt const &req = EVT_CAST(*e);
              Evt *evt = new InstaSimStartCfm(req.GetFrom(), GET_HSMN(), req.GetSeq(), ERROR_SUCCESS);
              Fw::Post(evt);
              return Q_HANDLED();
          }
    }
    return Q_SUPER(&QHsm::top);
}

QState InstaPot::Stopped(InstaPot * const me, QEvt const * const e)
{
    switch (e->sig)
    {
        case Q_ENTRY_SIG:
        {
            EVENT(e);
            return Q_HANDLED();
        }
        case Q_EXIT_SIG:
        {
            EVENT(e);
            return Q_HANDLED();
        }
        case INSTA_SIM_PAUSE_REQ: {
        	PRINT("*****Stopped::INSTA_SIM_PAUSE_REQ****\r\n");
            EVENT(e);
            Evt const &req = EVT_CAST(*e);
            Evt *evt = new InstaSimPauseCfm(req.GetFrom(), GET_HSMN(), req.GetSeq(), ERROR_SUCCESS);
            Fw::Post(evt);
            return Q_HANDLED();
        }
        case INSTA_SIM_START_REQ: {
        	PRINT("*****Stopped::INSTA_SIM_START_REQ****\r\n");
            EVENT(e);
            Evt const &req = EVT_CAST(*e);
            Evt *evt = new InstaSimStartCfm(req.GetFrom(), GET_HSMN(), req.GetSeq(), ERROR_SUCCESS);
            Fw::Post(evt);
            return Q_TRAN(&InstaPot::Started);
        }
        case INSTA_SIM_TOGGLE: {
          	PRINT("*****Stopped::INSTA_SIM_TOGGLE****\r\n");
          	EVENT(e);
           	return Q_TRAN(&InstaPot::Started);
        }
    }
    return Q_SUPER(&InstaPot::Root);
}

QState InstaPot::Started(InstaPot * const me, QEvt const * const e)
{
    switch (e->sig)
    {
        case Q_ENTRY_SIG:
        {
            EVENT(e);
            //me->m_instaTimer.Start(5);
            return Q_HANDLED();
        }
        case Q_EXIT_SIG:
        {
            EVENT(e);
            //me->m_instaTimer.Stop();
            return Q_HANDLED();
        }
        case INSTA_SIM_START_REQ: {
        	PRINT("*****Started::INSTA_SIM_START_REQ****\r\n");
            EVENT(e);
            Evt const &req = EVT_CAST(*e);
            Evt *evt = new InstaSimStartCfm(req.GetFrom(), GET_HSMN(), req.GetSeq(), ERROR_SUCCESS);
            Fw::Post(evt);
            return Q_HANDLED();
        }
        case INSTA_SIM_PAUSE_REQ: {
            PRINT("*****Started::INSTA_SIM_PAUSE_REQ****\r\n");
            EVENT(e);
            Evt const &req = EVT_CAST(*e);
            Evt *evt = new InstaSimPauseCfm(req.GetFrom(), GET_HSMN(), req.GetSeq(), ERROR_SUCCESS);
            Fw::Post(evt);
            return Q_TRAN(&InstaPot::Stopped);
        }
        case INSTA_SIM_TOGGLE: {
          	PRINT("*****Started::INSTA_SIM_TOGGLE****\r\n");
          	EVENT(e);
           	return Q_TRAN(&InstaPot::Stopped);
        }

    }
    return Q_SUPER(&InstaPot::Root);
}



}
